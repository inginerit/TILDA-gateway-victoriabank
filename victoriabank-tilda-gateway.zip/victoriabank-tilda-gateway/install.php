<?php

/**
 * VictoriaBank Gateway — DB installer.
 * Run ONCE via browser: https://pay.yoursite.md/install
 * IMPORTANT: Delete this file or block access after installation!
 */

require_once __DIR__ . '/config.php';

$db  = vb_db()->getPdo();
$ok  = true;
$log = [];

$tables = [
    'vb_orders' => "CREATE TABLE IF NOT EXISTS `vb_orders` (
        `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `order_id`    VARCHAR(50) UNIQUE NOT NULL,
        `method`      ENUM('visa_master','starcard_rate','starcard_points','mia') NOT NULL,
        `amount`      DECIMAL(14,2) NOT NULL DEFAULT 0,
        `currency`    VARCHAR(10) NOT NULL DEFAULT 'MDL',
        `status`          ENUM('pending','authorized','processing','paid','failed','cancelled','refunded') DEFAULT 'pending',
        `rrn`             VARCHAR(50) DEFAULT '',
        `int_ref`         VARCHAR(100) DEFAULT '',
        `sent_21_at`      DATETIME DEFAULT NULL,
        `completion_done` TINYINT(1) NOT NULL DEFAULT 0,
        `mia_qr_uuid` VARCHAR(100) DEFAULT '',
        `mia_qr_header_uuid` VARCHAR(100) DEFAULT '',
        `mia_reference` VARCHAR(200) DEFAULT '',
        `return_url`  TEXT,
        `cancel_url`  TEXT,
        `notify_url`  TEXT,
        `description` VARCHAR(255) DEFAULT '',
        `raw_callback` TEXT,
        `created_at`  DATETIME DEFAULT CURRENT_TIMESTAMP,
        `updated_at`  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_method` (`method`),
        KEY `idx_status` (`status`),
        KEY `idx_mia_uuid` (`mia_qr_uuid`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    'vb_mia_tokens' => "CREATE TABLE IF NOT EXISTS `vb_mia_tokens` (
        `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `token`      TEXT NOT NULL,
        `expires_at` DATETIME NOT NULL,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
];

foreach ($tables as $name => $sql) {
    try {
        $db->exec($sql);
        $log[] = "✓ Table `{$name}` created (or already exists)";
    }
    catch (PDOException $e) {
        $ok    = false;
        $log[] = "✗ Table `{$name}` FAILED: " . $e->getMessage();
    }
}

// Migrations — safe to run on existing installs
$migrations = [
    'Add mia_qr_header_uuid column' =>
        "ALTER TABLE `vb_orders` ADD COLUMN `mia_qr_header_uuid` VARCHAR(100) NOT NULL DEFAULT '' AFTER `mia_qr_uuid`",
];

foreach ($migrations as $desc => $sql) {
    try {
        $db->exec($sql);
        $log[] = "✓ Migration: {$desc}";
    }
    catch (PDOException $e) {
        if (str_contains($e->getMessage(), 'Duplicate column')) {
            $log[] = "~ Migration skipped (already applied): {$desc}";
        } else {
            $ok    = false;
            $log[] = "✗ Migration FAILED ({$desc}): " . $e->getMessage();
        }
    }
}

header('Content-Type: text/html; charset=utf-8');
echo '<pre>';
echo "VictoriaBank Gateway — Installation\n";
echo "====================================\n\n";
foreach ($log as $line) {
    echo $line . "\n";
}
echo "\n" . ($ok ? '✓ Installation complete!' : '✗ Some errors occurred.') . "\n";
echo "\n⚠ DELETE or BLOCK this file after installation!\n";
echo '</pre>';
