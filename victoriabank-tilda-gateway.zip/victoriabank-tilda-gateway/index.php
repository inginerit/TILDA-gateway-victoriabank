<?php

/**
 * VictoriaBank Tilda Payment Gateway — main router.
 *
 * Routes:
 *   GET  /pay                      → payment selection / redirect to bank
 *   POST /callback                 → bank POST callback (e-Gateway)
 *   POST /mia/webhook              → MIA JWT webhook
 *   GET  /mia/status               → AJAX status polling
 *   GET  /mia/payment              → MIA QR page
 *   GET  /admin                    → admin dashboard
 *   POST /admin/settings           → save settings
 *   GET  /install                  → DB install (delete after use)
 *
 * Integration with Tilda:
 *   After order, Tilda redirects to:
 *   https://pay.yoursite.md/pay?method=visa_master&order_id=123&amount=150.00
 *     &currency=MDL&description=Order+123&return_url=https://...&cancel_url=https://...
 *     &notify_url=https://...
 */

define('VB_START', microtime(true));

require_once __DIR__ . '/config.php';

// Parse route
$uri    = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// Strip base path if gateway is in a subdirectory
$basePath = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/');
if ($basePath && strpos($uri, $basePath) === 0) {
    $uri = substr($uri, strlen($basePath)) ?: '/';
}

$uri = '/' . ltrim($uri, '/');

// Session for admin
session_start();

// Route dispatch
try {
    switch (true) {
        case $uri === '/pay' && $method === 'GET':
            require VB_ROOT . '/pages/pay-card.php';
            break;

        case $uri === '/callback' && $method === 'POST':
            require VB_ROOT . '/pages/callback-card.php';
            break;

        case $uri === '/mia/webhook' && $method === 'POST':
            require VB_ROOT . '/pages/mia-webhook.php';
            break;

        case $uri === '/mia/status' && $method === 'GET':
            require VB_ROOT . '/pages/mia-status.php';
            break;

        case $uri === '/mia/payment' && $method === 'GET':
            require VB_ROOT . '/pages/pay-mia.php';
            break;

        case str_starts_with($uri, '/admin'):
            require VB_ROOT . '/admin/index.php';
            break;

        case $uri === '/install':
            require VB_ROOT . '/install.php';
            break;

        default:
            http_response_code(404);
            echo '<h1>Not Found</h1>';
            break;
    }
}
catch (\Throwable $e) {
    vb_logger()->error('Gateway exception: ' . $e->getMessage(), [
        'uri'   => $uri,
        'trace' => $e->getTraceAsString(),
    ]);
    http_response_code(500);
    echo '<h1>Gateway Error</h1><p>An internal error occurred. Please try again.</p>';
}
