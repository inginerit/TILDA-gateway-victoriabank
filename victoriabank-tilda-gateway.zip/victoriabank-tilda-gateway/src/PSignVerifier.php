<?php

/**
 * VictoriaBank callback P_SIGN verifier — standalone (no framework).
 *
 * Metoda: openssl_public_decrypt → strip DigestInfo prefix → compare hash.
 * Implementare după documentația oficială (P_SIGN_DECRYPT.PHP, P_SIGN_DECRYPTsha256 1.PHP).
 * MAC fields (ORDER CRITICAL): ACTION → RC → RRN → ORDER → AMOUNT
 * Câmp gol sau '-' → doar '-'. Nu se aplică trim().
 */
class VbPSignVerifier
{
    private const CALLBACK_FIELDS = ['ACTION', 'RC', 'RRN', 'ORDER', 'AMOUNT'];

    /** SHA-256 DigestInfo prefix (P_SIGN_DECRYPTsha256 1.PHP) */
    private const PREFIX_SHA256 = '3031300D060960864801650304020105000420';

    /** MD5 DigestInfo prefix (P_SIGN_DECRYPT.PHP) — fără '00' la început! */
    private const PREFIX_MD5 = '3020300C06082A864886F70D020505000410';

    private string $publicKeyPem;

    public function __construct(string $publicKeyPem)
    {
        $this->publicKeyPem = $publicKeyPem;
    }

    public function verify(array $params): bool
    {
        $pSign = $params['P_SIGN'] ?? '';
        if (!$pSign) {
            return false;
        }

        // Build MAC — fără trim(), exact ca în documentația oficială
        $mac = '';
        foreach (self::CALLBACK_FIELDS as $field) {
            $v = (string)($params[$field] ?? '');
            if ($v === '' || $v === '-') {
                $mac .= '-';
            } else {
                $mac .= strlen($v) . $v;
            }
        }

        $pubKey = openssl_pkey_get_public($this->publicKeyPem);
        if ($pubKey === false) {
            return false;
        }

        $sigBytes = hex2bin(strtolower($pSign));
        if ($sigBytes === false) {
            return false;
        }

        // Decriptare RSA cu PKCS1 padding — exact ca în documentația băncii
        $decryptedBin = '';
        if (!openssl_public_decrypt($sigBytes, $decryptedBin, $pubKey)) {
            return false;
        }

        $decryptedHex = strtoupper(bin2hex($decryptedBin));

        // SHA-256 (standard curent VictoriaBank)
        if (str_replace(self::PREFIX_SHA256, '', $decryptedHex) === strtoupper(hash('sha256', $mac))) {
            return true;
        }

        // MD5 fallback (terminale vechi / mediu de test)
        if (str_replace(self::PREFIX_MD5, '', $decryptedHex) === strtoupper(md5($mac))) {
            return true;
        }

        return false;
    }

    public function isSuccess(array $params): bool
    {
        return ($params['ACTION'] ?? '') === '0' && ($params['RC'] ?? '') === '00';
    }

    public function isCancelled(array $params): bool
    {
        return ($params['RC'] ?? '') === '-25';
    }

    public function parseResponse(string $body): array
    {
        // Format 1: URL-encoded
        if (strpos($body, '=') !== false && strpos($body, '<') === false) {
            parse_str($body, $p);
            if (!empty($p)) {
                return $p;
            }
        }

        // Format 2: HTML inputs
        $params = [];
        if (preg_match_all('/<input[^>]+>/i', $body, $m)) {
            foreach ($m[0] as $tag) {
                $name = $value = '';
                if (preg_match('/name=["\']([^"\']+)["\']/i', $tag, $nm)) {
                    $name = $nm[1];
                }
                if (preg_match('/value=["\']([^"\']*)["\']|value=(\S*)/i', $tag, $vm)) {
                    $value = html_entity_decode($vm[1] ?? $vm[2] ?? '');
                }
                if ($name) {
                    $params[$name] = $value;
                }
            }
            if (!empty($params)) {
                return $params;
            }
        }

        // Format 3: HTML table
        if (preg_match_all('/<td[^>]*>(.*?)<\/td>\s*<td[^>]*>(.*?)<\/td>/is', $body, $t)) {
            foreach ($t[1] as $i => $k) {
                $key = trim(strip_tags($k));
                if ($key) {
                    $params[$key] = trim(strip_tags($t[2][$i]));
                }
            }
        }

        return $params;
    }
}
