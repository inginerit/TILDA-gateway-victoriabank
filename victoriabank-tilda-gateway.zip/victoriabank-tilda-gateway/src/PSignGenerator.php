<?php

/**
 * VictoriaBank e-Gateway P_SIGN generator — standalone (no framework).
 */
class VbPSignGenerator
{
    private const AUTH_FIELDS = ['ORDER', 'NONCE', 'TIMESTAMP', 'TRTYPE', 'AMOUNT'];

    private string $privateKeyPem;

    public function __construct(string $privateKeyPem)
    {
        $this->privateKeyPem = $privateKeyPem;
    }

    public function generateNonce(): string
    {
        return strtoupper(bin2hex(random_bytes(20)));
    }

    public function generateTimestamp(): string
    {
        return gmdate('YmdHis');
    }

    public function formatOrderId($id): string
    {
        return str_pad((string) $id, 6, '0', STR_PAD_LEFT);
    }

    public function formatAmount($amount): string
    {
        return number_format((float) $amount, 2, '.', '');
    }

    /**
     * Normalize MERCH_GMT to bank-required short format (max 5 chars).
     * "+03:00" → "+3", "+02:00" → "+2"
     */
    private function normalizeGmt(string $gmt): string
    {
        $gmt = trim($gmt);
        if (preg_match('/^([+-]?)0*(\d+)(?::\d+)?$/', $gmt, $m)) {
            $sign  = ($m[1] === '-') ? '-' : '+';
            $hours = (int) $m[2];
            return $sign . $hours;
        }
        return substr($gmt, 0, 5);
    }

    /**
     * Build TRTYPE=0 authorization params.
     *
     * @param bool $includeAccntSel  Set TRUE for StarCard Points
     */
    public function buildAuthParams(array $data, bool $includeAccntSel = false): array
    {
        $ts    = $this->generateTimestamp();
        $nonce = $this->generateNonce();
        $order = $this->formatOrderId($data['order_id']);
        $amt   = $this->formatAmount($data['amount']);
        $trtype = '0';

        $params = [
            'ORDER'      => $order,
            'AMOUNT'     => $amt,
            'CURRENCY'   => $data['currency'] ?? 'MDL',
            'TERMINAL'   => $data['terminal_id'],
            'TRTYPE'     => $trtype,
            'TIMESTAMP'  => $ts,
            'NONCE'      => $nonce,
            'BACKREF'    => $data['backref'],
            'DESC'       => substr($data['description'] ?? '', 0, 50),
            'MERCH_NAME' => substr($data['merchant_name'] ?? '', 0, 50),
            'MERCH_URL'  => $data['merchant_url'] ?? '',
            'MERCHANT'   => $data['merchant_id'],
            'MERCH_GMT'  => $this->normalizeGmt($data['merchant_gmt'] ?? '+3'),
            'COUNTRY'    => strtolower($data['country'] ?? 'md'),
            'LANG'       => $data['language'] ?? 'RO',
        ];

        if (!empty($data['merchant_address'])) {
            $params['MERCH_ADDRESS'] = substr($data['merchant_address'], 0, 250);
        }

        if (!empty($data['email'])) {
            $params['EMAIL'] = $data['email'];
        }

        if ($includeAccntSel) {
            $params['ACCNT_SEL'] = '08';
        }

        vb_logger()->debug('buildAuthParams: ORDER=' . $order . ' AMOUNT=' . $amt . ' CURRENCY=' . ($data['currency'] ?? 'MDL')
            . ' TERMINAL=' . $data['terminal_id'] . ' NONCE_len=' . strlen($nonce)
            . ' GMT=' . $this->normalizeGmt($data['merchant_gmt'] ?? '+3')
            . ' COUNTRY=' . strtolower($data['country'] ?? 'md')
            . ' BACKREF=' . ($data['backref'] ?? ''));

        $params['P_SIGN'] = $this->sign([
            'ORDER'     => $order,
            'NONCE'     => $nonce,
            'TIMESTAMP' => $ts,
            'TRTYPE'    => $trtype,
            'AMOUNT'    => $amt,
        ]);

        return $params;
    }

    public function buildCompletionParams(array $data): array
    {
        $ts    = $this->generateTimestamp();
        $nonce = $this->generateNonce();
        $trtype = '21';
        $order = $this->formatOrderId($data['order_id']);
        $amt   = $this->formatAmount($data['amount']);

        $params = [
            'ORDER'     => $order,
            'AMOUNT'    => $amt,
            'CURRENCY'  => $data['currency'] ?? 'MDL',
            'TERMINAL'  => $data['terminal_id'],
            'TRTYPE'    => $trtype,
            'TIMESTAMP' => $ts,
            'NONCE'     => $nonce,
            'RRN'       => $data['rrn'],
            'INT_REF'   => $data['int_ref'],
        ];

        $params['P_SIGN'] = $this->sign([
            'ORDER'     => $order,
            'NONCE'     => $nonce,
            'TIMESTAMP' => $ts,
            'TRTYPE'    => $trtype,
            'AMOUNT'    => $amt,
        ]);

        return $params;
    }

    public function buildReversalParams(array $data): array
    {
        $params = $this->buildCompletionParams($data);
        $params['TRTYPE'] = '24';
        $params['P_SIGN'] = $this->sign([
            'ORDER'     => $params['ORDER'],
            'NONCE'     => $params['NONCE'],
            'TIMESTAMP' => $params['TIMESTAMP'],
            'TRTYPE'    => '24',
            'AMOUNT'    => $params['AMOUNT'],
        ]);
        return $params;
    }

    /** TRTYPE=90: NO P_SIGN, NO TIMESTAMP, NO NONCE */
    public function buildStatusParams(array $data): array
    {
        return [
            'TERMINAL'    => $data['terminal_id'],
            'TRTYPE'      => '90',
            'TRAN_TRTYPE' => '0',
            'ORDER'       => $this->formatOrderId($data['order_id']),
        ];
    }

    private function sign(array $values): string
    {
        $mac        = '';
        $macDetails = [];
        foreach (self::AUTH_FIELDS as $field) {
            $v = $values[$field] ?? '';
            if ($v !== '') {
                $mac         .= strlen($v) . $v;
                $macDetails[] = $field . '(' . strlen($v) . ')=' . $v;
            } else {
                $macDetails[] = $field . '=EMPTY(skipped)';
            }
        }

        vb_logger()->debug('P_SIGN MAC fields: ' . implode(', ', $macDetails));
        vb_logger()->debug('P_SIGN MAC string: ' . $mac);

        $key = openssl_pkey_get_private($this->privateKeyPem);
        if ($key === false) {
            $err = openssl_error_string();
            vb_logger()->error('P_SIGN: invalid private key — ' . $err);
            throw new RuntimeException('VictoriaBank: invalid private key — ' . $err);
        }

        $sig = '';
        if (!openssl_sign($mac, $sig, $key, OPENSSL_ALGO_SHA256)) {
            $err = openssl_error_string();
            vb_logger()->error('P_SIGN: signing failed — ' . $err);
            throw new RuntimeException('VictoriaBank: signing failed — ' . $err);
        }

        $psign = strtoupper(bin2hex($sig));
        vb_logger()->debug('P_SIGN result: ' . substr($psign, 0, 32) . '... (length=' . strlen($psign) . ')');

        // Self-verify: catch key pair mismatch early
        $pubKeyPem = openssl_pkey_get_details($key)['key'] ?? '';
        if ($pubKeyPem) {
            $pubKey = openssl_pkey_get_public($pubKeyPem);
            if ($pubKey) {
                $selfVerify = openssl_verify($mac, $sig, $pubKey, OPENSSL_ALGO_SHA256);
                if ($selfVerify !== 1) {
                    vb_logger()->error('P_SIGN self-verify FAILED (result=' . $selfVerify . ') — private/public key pair mismatch!');
                } else {
                    vb_logger()->debug('P_SIGN self-verify OK');
                }
            }
        }

        return $psign;
    }
}
