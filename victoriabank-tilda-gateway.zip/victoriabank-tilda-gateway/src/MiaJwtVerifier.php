<?php

/**
 * MIA JWT RS256 webhook verifier — standalone (no framework).
 */
class VbMiaJwtVerifier
{
    private string $certPath;
    private mixed  $publicKey = null;

    public function __construct(string $certPath)
    {
        $this->certPath = $certPath;
    }

    /**
     * Verify MIA webhook body and return decoded payload.
     *
     * @param string $rawBody  JSON-encoded JWT string from bank
     *
     * @return array|null  Payload on success, null on failure.
     */
    public function verifyAndDecode(string $rawBody): ?array
    {
        if (!$rawBody) {
            return null;
        }

        $trimmed  = trim($rawBody);
        $jwtToken = null;

        if ($trimmed !== '' && $trimmed[0] === '"') {
            // Format 1: JSON-encoded string — "eyJ..."
            $decoded  = json_decode($trimmed);
            $jwtToken = is_string($decoded) ? $decoded : null;
        }
        elseif ($trimmed !== '' && $trimmed[0] !== '{' && $trimmed[0] !== '[') {
            // Format 2: plain JWT string
            $jwtToken = $trimmed;
        }
        else {
            // Format 3: JSON object with token/jwt/jwtToken key
            $data = json_decode($trimmed, true);
            if (is_array($data)) {
                $jwtToken = $data['token'] ?? $data['jwt'] ?? $data['jwtToken'] ?? null;
            }
        }

        if (!$jwtToken) {
            return null;
        }

        $jwtToken = preg_replace('/[^a-zA-Z0-9._\-]/', '', $jwtToken);

        return $this->verify($jwtToken);
    }

    public function verify(string $jwt): ?array
    {
        $parts = explode('.', $jwt);
        if (count($parts) !== 3) {
            return null;
        }

        [$headerB64, $payloadB64, $sigB64] = $parts;

        $payloadJson = base64_decode(strtr($payloadB64, '-_', '+/') . '==');
        $payload     = json_decode($payloadJson, true);
        if (!is_array($payload)) {
            return null;
        }

        $signature  = base64_decode(strtr($sigB64, '-_', '+/') . '==');
        $signedData = $headerB64 . '.' . $payloadB64;

        $pubKey = $this->getPublicKey();
        if (!$pubKey) {
            return null;
        }

        $ok = openssl_verify($signedData, $signature, $pubKey, OPENSSL_ALGO_SHA256);
        return ($ok === 1) ? $payload : null;
    }

    private function getPublicKey(): mixed
    {
        if ($this->publicKey !== null) {
            return $this->publicKey;
        }

        if (!file_exists($this->certPath)) {
            throw new RuntimeException('MIA: VBCA.crt not found: ' . $this->certPath);
        }

        $certPem = file_get_contents($this->certPath);
        $cert    = openssl_x509_read($certPem);
        if (!$cert) {
            throw new RuntimeException('MIA: cannot read VBCA.crt');
        }

        $this->publicKey = openssl_pkey_get_public($cert);
        return $this->publicKey;
    }
}
