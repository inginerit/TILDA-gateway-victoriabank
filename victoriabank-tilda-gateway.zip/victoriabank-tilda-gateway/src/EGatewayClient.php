<?php

/**
 * VictoriaBank e-Gateway HTTP client — sends and receives bank requests.
 */
class VbEGatewayClient
{
    const ENDPOINT_TEST = 'https://ecomt.victoriabank.md/cgi-bin/cgi_link';
    const ENDPOINT_PROD = 'https://vb059.vb.md/cgi-bin/cgi_link';

    private bool $testMode;
    private string $endpoint;
    private VbPSignGenerator $generator;
    private VbPSignVerifier  $verifier;

    public function __construct(
        string $privateKeyPem,
        string $publicKeyPem,
        bool $testMode = true
    ) {
        $this->testMode  = $testMode;
        $this->endpoint  = $testMode ? self::ENDPOINT_TEST : self::ENDPOINT_PROD;
        $this->generator = new VbPSignGenerator($privateKeyPem);
        $this->verifier  = new VbPSignVerifier($publicKeyPem);
    }

    public function getGenerator(): VbPSignGenerator
    {
        return $this->generator;
    }

    public function getVerifier(): VbPSignVerifier
    {
        return $this->verifier;
    }

    public function getEndpoint(): string
    {
        return $this->endpoint;
    }

    /**
     * Build HTML auto-submit form to redirect customer to bank.
     */
    public function buildRedirectForm(array $params, string $formId = 'vb-redirect-form'): string
    {
        $fields = '';
        foreach ($params as $name => $value) {
            $fields .= sprintf(
                '<input type="hidden" name="%s" value="%s">',
                htmlspecialchars($name, ENT_QUOTES),
                htmlspecialchars((string) $value, ENT_QUOTES)
            );
        }

        return <<<HTML
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Redirecting to bank...</title></head>
<body>
<p>You are being redirected to the secure payment page. Please wait...</p>
<form id="{$formId}" method="POST" action="{$this->endpoint}">
{$fields}
</form>
<script>document.getElementById('{$formId}').submit();</script>
</body>
</html>
HTML;
    }

    /**
     * Send TRTYPE=21 completion or TRTYPE=24 reversal to bank and return parsed response.
     */
    public function sendRequest(array $params): array
    {
        $body = http_build_query($params);

        $ch = curl_init($this->endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
        ]);

        $responseBody = curl_exec($ch);
        $status       = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error        = curl_error($ch);
        curl_close($ch);

        vb_logger()->info('EGW Request sent', [
            'order'   => $params['ORDER']  ?? '',
            'trtype'  => $params['TRTYPE'] ?? '',
            'amount'  => $params['AMOUNT'] ?? '',
        ]);
        vb_logger()->info('EGW Response received', [
            'http_code' => $status,
            'body_len'  => strlen((string)$responseBody),
        ]);

        if ($error) {
            throw new RuntimeException('e-Gateway HTTP error: ' . $error);
        }

        return $this->verifier->parseResponse((string) $responseBody);
    }

    /**
     * Execute TRTYPE=21 (completion) — should be called after AUTH callback.
     */
    public function complete(array $orderData): array
    {
        $params = $this->generator->buildCompletionParams($orderData);
        return $this->sendRequest($params);
    }

    /**
     * Execute TRTYPE=24 (reversal/refund).
     */
    public function reverse(array $orderData): array
    {
        $params = $this->generator->buildReversalParams($orderData);
        return $this->sendRequest($params);
    }

    /**
     * Execute TRTYPE=90 (status check).
     */
    public function checkStatus(array $orderData): array
    {
        $params = $this->generator->buildStatusParams($orderData);
        return $this->sendRequest($params);
    }
}
