<?php

/**
 * VictoriaBank MIA IPS API client — standalone (no framework).
 * Token cached in DB table vb_mia_tokens.
 */
class VbMiaApiClient
{
    const TEST_BASE = 'https://test-ipspj.victoriabank.md';
    const PROD_BASE = 'https://ips-api-pj.vb.md';

    private string $username;
    private string $password;
    private bool   $testMode;
    private string $baseUrl;
    private VbDatabase $db;

    public function __construct(VbDatabase $db, string $username, string $password, bool $testMode = true)
    {
        $this->db       = $db;
        $this->username = $username;
        $this->password = $password;
        $this->testMode = $testMode;
        $this->baseUrl  = $testMode ? self::TEST_BASE : self::PROD_BASE;
    }

    public function getToken(): string
    {
        // Check DB cache
        $row = $this->db->fetchOne(
            'SELECT token FROM vb_mia_tokens WHERE expires_at > NOW() ORDER BY id DESC LIMIT 1'
        );
        if ($row && !empty($row['token'])) {
            return $row['token'];
        }

        // Fetch new token
        $response = $this->httpPost(
            $this->baseUrl . '/identity/token',
            http_build_query([
                'grant_type' => 'password',
                'username'   => $this->username,
                'password'   => $this->password,
            ]),
            ['Content-Type: application/x-www-form-urlencoded']
        );

        $data  = json_decode($response['body'], true);
        $token = $data['accessToken'] ?? '';
        if (!$token) {
            throw new RuntimeException('MIA auth failed: ' . $response['body']);
        }

        $expiry = (int)($data['expiresIn'] ?? 3600);

        $this->db->execute(
            'DELETE FROM vb_mia_tokens WHERE expires_at <= NOW()'
        );
        $this->db->execute(
            'INSERT INTO vb_mia_tokens (token, expires_at) VALUES (?, DATE_ADD(NOW(), INTERVAL ? SECOND))',
            [$token, $expiry - 60]
        );

        return $token;
    }

    /**
     * Create a dynamic QR code.
     *
     * @param array $params  Keys: amount, currency, iban, merchant_name,
     *   description, order_ref, ttl_minutes, return_url
     */
    public function createQr(array $params): array
    {
        $token = $this->getToken();

        $body = [
            'header'    => [
                'qrType'     => 'DYNM',
                'amountType' => 'Fixed',
                'pmtContext' => 'e',
            ],
            'extension' => [
                'creditorAccount'      => ['iban' => $params['iban']],
                'dba'                  => substr($params['merchant_name'], 0, 25),
                'remittanceInfo4Payer' => substr($params['description'], 0, 35),
                'creditorRef'          => substr($params['order_ref'], 0, 35),
                'amount'               => [
                    'sum'      => number_format((float) $params['amount'], 2, '.', ''),
                    'currency' => $params['currency'] ?? 'MDL',
                ],
                'ttl'                  => [
                    'length' => (int) ($params['ttl_minutes'] ?? 5),
                    'units'  => 'mm',
                ],
            ],
        ];

        if (!empty($params['return_url'])) {
            $body['extension']['ReturnUrl'] = $params['return_url'];
        }

        $w = $params['width'] ?? 300;
        $h = $params['height'] ?? 300;

        $response = $this->httpPost(
            "{$this->baseUrl}/api/v1/qr?width={$w}&height={$h}",
            json_encode($body),
            [
                'Content-Type: application/json',
                'Accept: application/json',
                'Authorization: Bearer ' . $token,
            ]
        );

        if ($response['status'] === 401) {
            $this->clearToken();
            throw new RuntimeException('MIA: token expired (401)');
        }

        if ($response['status'] >= 400) {
            throw new RuntimeException('MIA QR creation failed: HTTP ' . $response['status'] . ' — ' . $response['body']);
        }

        $data = json_decode($response['body'], true);
        if (empty($data['qrExtensionUUID'])) {
            throw new RuntimeException('MIA QR: missing qrExtensionUUID — ' . $response['body']);
        }

        return $data;
    }

    /**
     * Check QR payment status.
     * Endpoint: GET /api/v1/qr/{qrHeaderUUID}/status
     * Always returns ['status' => string, 'raw' => array].
     */
    public function checkStatus(string $headerUuid): array
    {
        $token = $this->getToken();

        $response = $this->httpGet(
            "{$this->baseUrl}/api/v1/qr/" . urlencode($headerUuid) . '/status',
            ['Authorization: Bearer ' . $token, 'Accept: application/json']
        );

        if ($response['status'] >= 400) {
            throw new RuntimeException('MIA status check failed: HTTP ' . $response['status']);
        }

        $data = json_decode($response['body'], true) ?? [];
        return [
            'status' => (string)($data['status'] ?? 'Unknown'),
            'raw'    => $data,
        ];
    }

    /**
     * Delete (refund) a MIA transaction.
     * DELETE /api/v1/transaction/{refundRef}
     * Returns HTTP status code: 204 = success.
     */
    public function deleteTransaction(string $refundRef): int
    {
        $token    = $this->getToken();
        $response = $this->httpDelete(
            "{$this->baseUrl}/api/v1/transaction/" . urlencode($refundRef),
            ['Authorization: Bearer ' . $token]
        );
        return (int)$response['status'];
    }

    public function refund(string $reference): bool
    {
        $parts = explode('|', $reference);
        $txId  = $parts[3] ?? '';
        if (!$txId) {
            throw new InvalidArgumentException('MIA: cannot extract TX ID from: ' . $reference);
        }

        $token = $this->getToken();

        $response = $this->httpDelete(
            "{$this->baseUrl}/api/v1/transaction/{$txId}",
            ['Authorization: Bearer ' . $token]
        );

        if ($response['status'] === 401) {
            $this->clearToken();
            throw new RuntimeException('MIA refund: token expired');
        }

        if ($response['status'] === 404) {
            throw new RuntimeException("MIA refund: not found: {$txId}");
        }

        return $response['status'] === 204;
    }

    public function clearToken(): void
    {
        $this->db->execute('DELETE FROM vb_mia_tokens');
    }

    public function isPaid(array $status): bool
    {
        return ($status['status'] ?? '') === 'Paid';
    }

    public function isFinal(array $status): bool
    {
        return in_array($status['status'] ?? '', ['Paid', 'Expired', 'Cancelled', 'Inactive']);
    }

    public function extractTransactionId(array $status): ?string
    {
        $payments = $status['payments'] ?? [];
        if (empty($payments)) {
            return null;
        }
        $parts = explode('|', $payments[0]['reference'] ?? '');
        return $parts[3] ?? null;
    }

    // ─── cURL helpers ───────────────────────────────────────────────────────

    private function httpPost(string $url, string $body, array $headers = []): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $responseBody = curl_exec($ch);
        $statusCode   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error        = curl_error($ch);
        curl_close($ch);

        if ($error) {
            throw new RuntimeException('MIA HTTP error: ' . $error);
        }

        return ['status' => $statusCode, 'body' => $responseBody];
    }

    private function httpGet(string $url, array $headers = []): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $responseBody = curl_exec($ch);
        $statusCode   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error        = curl_error($ch);
        curl_close($ch);

        if ($error) {
            throw new RuntimeException('MIA HTTP error: ' . $error);
        }

        return ['status' => $statusCode, 'body' => $responseBody];
    }

    private function httpDelete(string $url, array $headers = []): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST  => 'DELETE',
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $responseBody = curl_exec($ch);
        $statusCode   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error        = curl_error($ch);
        curl_close($ch);

        if ($error) {
            throw new RuntimeException('MIA HTTP error: ' . $error);
        }

        return ['status' => $statusCode, 'body' => $responseBody];
    }
}
