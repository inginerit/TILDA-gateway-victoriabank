<?php

/**
 * File-based logger for the VictoriaBank Tilda gateway.
 */
class VbLogger
{
    private string $logDir;
    private static ?VbLogger $instance = null;

    private function __construct(string $logDir)
    {
        $this->logDir = rtrim($logDir, '/\\');
        if (!is_dir($this->logDir)) {
            mkdir($this->logDir, 0755, true);
        }
    }

    public static function getInstance(string $logDir = ''): self
    {
        if (self::$instance === null) {
            if (!$logDir) {
                $logDir = __DIR__ . '/../logs';
            }
            self::$instance = new self($logDir);
        }
        return self::$instance;
    }

    public function info(string $message, array $context = []): void
    {
        $this->write('INFO', $message, $context);
    }

    public function warning(string $message, array $context = []): void
    {
        $this->write('WARNING', $message, $context);
    }

    public function error(string $message, array $context = []): void
    {
        $this->write('ERROR', $message, $context);
    }

    public function debug(string $message, array $context = []): void
    {
        $this->write('DEBUG', $message, $context);
    }

    private function write(string $level, string $message, array $context): void
    {
        $date    = date('Y-m-d');
        $logFile = $this->logDir . "/vb-gateway-{$date}.log";

        $ctx  = empty($context) ? '' : ' ' . json_encode($context, JSON_UNESCAPED_UNICODE);
        $line = sprintf(
            "[%s] [%s] %s%s\n",
            date('Y-m-d H:i:s'),
            $level,
            $message,
            $ctx
        );

        file_put_contents($logFile, $line, FILE_APPEND | LOCK_EX);
    }
}
