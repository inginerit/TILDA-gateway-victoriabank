/**
 * VictoriaBank MIA payment — device detection, deeplink, polling.
 * Standalone — no framework dependencies.
 */
(function () {
  'use strict';

  function isMobileDevice() {
    return /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
  }

  var _pollTimer = null;

  function startPolling(uuid, statusUrl, returnUrl, cancelUrl) {
    var attempts = 0;
    var MAX = 60; // 5 min at 5s

    _pollTimer = setInterval(function () {
      attempts++;

      fetch(statusUrl + '?uuid=' + encodeURIComponent(uuid), {
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          setStatusMsg(d.status);

          if (d.status === 'Paid') {
            clearInterval(_pollTimer);
            window.location.href = d.return_url || returnUrl;
            return;
          }

          if (['Expired', 'Cancelled', 'Inactive'].indexOf(d.status) >= 0 || attempts >= MAX) {
            clearInterval(_pollTimer);
            window.location.href = d.cancel_url || cancelUrl;
          }
        })
        .catch(function (e) {
          console.warn('MIA poll error', e);
        });
    }, 5000);
  }

  function setStatusMsg(status) {
    var labels = {
      'Active':    'Se așteaptă plata...',
      'Paid':      'Plată confirmată! Redirecționare...',
      'Expired':   'Codul QR a expirat.',
      'Cancelled': 'Plată anulată.',
      'Inactive':  'Plată inactivă.',
    };
    var msg = labels[status] || 'Verificare...';
    ['vb-status-msg', 'vb-status-msg-mobile'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.textContent = msg;
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    var wrapper = document.getElementById('vb-mia-wrapper');
    if (!wrapper) return;

    var uuid      = wrapper.dataset.uuid;
    var returnUrl = wrapper.dataset.returnUrl;
    var cancelUrl = wrapper.dataset.cancelUrl;
    var statusUrl = wrapper.dataset.statusUrl;

    if (!uuid) return;

    if (isMobileDevice()) {
      var desktop = document.getElementById('vb-desktop');
      var mobile  = document.getElementById('vb-mobile');
      if (desktop) desktop.style.display = 'none';
      if (mobile)  mobile.style.display  = 'block';

      if (typeof vbQrText !== 'undefined' && vbQrText) {
        var deepLink = 'https://mia.bnm.md/qr?data=' + encodeURIComponent(vbQrText);
        var btn = document.getElementById('vb-deeplink-btn');
        if (btn) {
          btn.href = deepLink;
          setTimeout(function () { window.location.href = deepLink; }, 800);
        }
      }
    }

    startPolling(uuid, statusUrl, returnUrl, cancelUrl);
  });
})();
