<?php
/**
 * Admin login form.
 */
$loginError = $loginError ?? '';
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>VictoriaBank Gateway — Login</title>
<style>
  body{font-family:Arial,sans-serif;background:#f5f5f5;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
  .box{background:#fff;border-radius:10px;padding:40px 32px;box-shadow:0 2px 16px rgba(0,0,0,.1);width:320px;text-align:center}
  h2{color:#c8102e;margin-bottom:24px}
  input[type=password]{width:100%;padding:12px;border:1px solid #ddd;border-radius:6px;font-size:15px;margin-bottom:16px;box-sizing:border-box}
  button{width:100%;background:#c8102e;color:#fff;border:none;padding:13px;border-radius:6px;font-size:15px;cursor:pointer}
  button:hover{background:#a30e26}
  .error{color:#c8102e;font-size:13px;margin-top:8px}
</style>
</head>
<body>
<div class="box">
  <h2>Gateway Admin</h2>
  <form method="POST">
    <input type="password" name="admin_pass" placeholder="Admin password" autofocus required>
    <button type="submit">Login</button>
    <?php if ($loginError): ?>
      <p class="error"><?= htmlspecialchars($loginError, ENT_QUOTES) ?></p>
    <?php endif; ?>
  </form>
</div>
</body>
</html>
