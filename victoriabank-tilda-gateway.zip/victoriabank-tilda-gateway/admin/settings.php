<?php

/**
 * Admin settings page — shows current config.json values.
 * Editing requires direct file modification (for security).
 */

$configFile   = VB_ROOT . '/config.json';
$configRaw    = file_get_contents($configFile);
$saveSuccess  = false;
$saveError    = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['config_json'])) {
    $newJson = $_POST['config_json'];
    $decoded = json_decode($newJson, true);
    if ($decoded === null) {
        $saveError = 'Invalid JSON. Please check the syntax.';
    }
    else {
        // Never allow admin_password to be empty
        if (empty($decoded['admin_password'])) {
            $saveError = 'Admin password cannot be empty.';
        }
        else {
            file_put_contents($configFile, json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
            $configRaw   = file_get_contents($configFile);
            $saveSuccess = true;
        }
    }
}

// Mask secrets for display
$displayConfig = json_decode($configRaw, true);
if ($displayConfig) {
    $displayConfig['admin_password']        = '*** (hidden)';
    $displayConfig['egw']['private_key_path'] = $displayConfig['egw']['private_key_path'] ?? '';
    if (!empty($displayConfig['mia']['api_password'])) {
        $displayConfig['mia']['api_password'] = '*** (hidden)';
    }
}

?>
<div class="card">
  <h3 style="margin-top:0">Gateway Settings</h3>
  <p style="color:#888;font-size:13px">Edit <code>config.json</code> directly on the server for security. Below is a read-only view of current settings (secrets masked).</p>

  <?php if ($saveSuccess): ?>
    <div style="background:#d4edda;color:#155724;padding:12px;border-radius:6px;margin-bottom:16px">
      Settings saved successfully.
    </div>
  <?php endif; ?>
  <?php if ($saveError): ?>
    <div style="background:#f8d7da;color:#721c24;padding:12px;border-radius:6px;margin-bottom:16px">
      <?= htmlspecialchars($saveError, ENT_QUOTES) ?>
    </div>
  <?php endif; ?>

  <table style="width:100%;font-size:13px;border-collapse:collapse">
    <tr style="background:#f8f8f8"><th style="padding:8px 12px;text-align:left">Setting</th><th style="padding:8px 12px;text-align:left">Value</th></tr>
    <tr><td style="padding:8px 12px;color:#555">Test Mode</td><td><?= VB_TEST_MODE ? '✓ Yes (TEST)' : '✗ No (LIVE)' ?></td></tr>
    <tr style="background:#f8f8f8"><td style="padding:8px 12px;color:#555">Terminal ID</td><td><?= htmlspecialchars(VB_EGW_TERMINAL, ENT_QUOTES) ?: '<em style="color:#999">not set</em>' ?></td></tr>
    <tr><td style="padding:8px 12px;color:#555">Merchant ID</td><td><?= htmlspecialchars(VB_EGW_MERCHANT, ENT_QUOTES) ?: '<em style="color:#999">not set</em>' ?></td></tr>
    <tr style="background:#f8f8f8"><td style="padding:8px 12px;color:#555">Merchant Name</td><td><?= htmlspecialchars(VB_EGW_MERCH_NAME, ENT_QUOTES) ?></td></tr>
    <tr><td style="padding:8px 12px;color:#555">Private Key</td><td><?= VB_PRIVATE_KEY_PEM ? '✓ Loaded' : '✗ NOT loaded' ?></td></tr>
    <tr style="background:#f8f8f8"><td style="padding:8px 12px;color:#555">Public Key</td><td><?= VB_PUBLIC_KEY_PEM ? '✓ Loaded' : '✗ NOT loaded' ?></td></tr>
    <tr><td style="padding:8px 12px;color:#555">MIA Username</td><td><?= htmlspecialchars(VB_MIA_USERNAME, ENT_QUOTES) ?: '<em style="color:#999">not set</em>' ?></td></tr>
    <tr style="background:#f8f8f8"><td style="padding:8px 12px;color:#555">MIA IBAN</td><td><?= htmlspecialchars(VB_MIA_IBAN, ENT_QUOTES) ?: '<em style="color:#999">not set</em>' ?></td></tr>
    <tr><td style="padding:8px 12px;color:#555">VBCA.crt</td><td><?= file_exists(VB_MIA_CERT_PATH) ? '✓ Found' : '✗ Not found: ' . htmlspecialchars(VB_MIA_CERT_PATH, ENT_QUOTES) ?></td></tr>
    <tr style="background:#f8f8f8"><td style="padding:8px 12px;color:#555">Visa/Master</td><td><?= VB_ENABLE_VISA ? '✓ Enabled' : '✗ Disabled' ?></td></tr>
    <tr><td style="padding:8px 12px;color:#555">StarCard Rate</td><td><?= VB_ENABLE_RATE ? '✓ Enabled' : '✗ Disabled' ?></td></tr>
    <tr style="background:#f8f8f8"><td style="padding:8px 12px;color:#555">StarCard Points</td><td><?= VB_ENABLE_POINTS ? '✓ Enabled' : '✗ Disabled' ?></td></tr>
    <tr><td style="padding:8px 12px;color:#555">MIA</td><td><?= VB_ENABLE_MIA ? '✓ Enabled' : '✗ Disabled' ?></td></tr>
  </table>

  <p style="margin-top:20px;font-size:13px;color:#888">
    To change settings, edit <code><?= htmlspecialchars($configFile, ENT_QUOTES) ?></code> on the server and reload.
  </p>
</div>
