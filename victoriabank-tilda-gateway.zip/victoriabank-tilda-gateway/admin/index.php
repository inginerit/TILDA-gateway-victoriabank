<?php

/**
 * VictoriaBank Gateway — Admin Panel.
 * Simple session-based authentication.
 */

// Load config if accessed directly (e.g. Apache serves admin/index.php without going through router)
if (!defined('VB_ADMIN_PASSWORD')) {
    require_once dirname(__DIR__) . '/config.php';
    session_start();
}

$action = $_GET['action'] ?? 'dashboard';

// Auth check
if (!isset($_SESSION['vb_admin']) || $_SESSION['vb_admin'] !== true) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_pass'])) {
        if ($_POST['admin_pass'] === VB_ADMIN_PASSWORD) {
            $_SESSION['vb_admin'] = true;
            header('Location: ' . VB_GATEWAY_URL . '/admin');
            exit;
        }
        $loginError = 'Invalid password.';
    }
    // Show login form
    require __DIR__ . '/auth.php';
    exit;
}

// Logout
if ($action === 'logout') {
    session_destroy();
    header('Location: ' . VB_GATEWAY_URL . '/admin');
    exit;
}

$db     = vb_db();
$logger = vb_logger();

// Stats
$stats = [
    'total'      => $db->fetchOne('SELECT COUNT(*) AS c FROM vb_orders')['c'] ?? 0,
    'paid'       => $db->fetchOne("SELECT COUNT(*) AS c FROM vb_orders WHERE status='paid'")['c'] ?? 0,
    'pending'    => $db->fetchOne("SELECT COUNT(*) AS c FROM vb_orders WHERE status='pending'")['c'] ?? 0,
    'failed'     => $db->fetchOne("SELECT COUNT(*) AS c FROM vb_orders WHERE status='failed'")['c'] ?? 0,
    'total_paid' => $db->fetchOne("SELECT COALESCE(SUM(amount),0) AS s FROM vb_orders WHERE status='paid'")['s'] ?? 0,
];

// Orders
$page    = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 25;
$offset  = ($page - 1) * $perPage;
$statusFilter = $_GET['status'] ?? '';
$where   = $statusFilter ? "WHERE status='" . $db->getPdo()->quote($statusFilter) . "'" : '';

$orders = $db->fetchAll(
    "SELECT * FROM vb_orders {$where} ORDER BY created_at DESC LIMIT {$perPage} OFFSET {$offset}"
);

// Handle refund
if ($action === 'refund' && isset($_GET['order_id'])) {
    $refOrderId = htmlspecialchars($_GET['order_id'], ENT_QUOTES);
    $refOrder   = $db->fetchOne('SELECT * FROM vb_orders WHERE order_id=? AND status="paid"', [$refOrderId]);

    if ($refOrder) {
        try {
            if ($refOrder['method'] === 'mia') {
                $mia       = vb_mia();
                $reference = $refOrder['mia_reference'];
                $logger->info('MIA refund attempt', [
                    'order_id'  => $refOrderId,
                    'reference' => $reference,
                ]);
                $httpCode = $mia->refundWithCode($reference);
                $success  = ($httpCode === 204 || $httpCode === 404);
                $logger->info('MIA refund result', [
                    'order_id'  => $refOrderId,
                    'http_code' => $httpCode,
                    'success'   => $success,
                ]);
                if ($httpCode === 404) {
                    // 404 = transaction not found / already refunded — mark as refunded in DB
                    $refundMsg = 'MIA: transaction already refunded or not found (404). Order marked refunded.';
                } elseif (!$success) {
                    $refundMsg = 'MIA refund API returned HTTP ' . $httpCode . '. Order NOT refunded.';
                }
            }
            else {
                $egw = vb_egw();
                // StarCard uses separate terminal if configured
                $isStarCard  = in_array($refOrder['method'], ['starcard_rate', 'starcard_points'], true);
                $terminalId  = ($isStarCard && VB_SC_TERMINAL) ? VB_SC_TERMINAL : VB_EGW_TERMINAL;
                // IMPORTANT: order_id must be the numeric DB id (bank ORDER), not the external string
                $result  = $egw->reverse([
                    'order_id'    => (int) $refOrder['id'],   // numeric bank ORDER
                    'amount'      => $refOrder['amount'],
                    'currency'    => $refOrder['currency'],   // '06S' for Points, 'MDL' for Rate/Visa
                    'terminal_id' => $terminalId,
                    'rrn'         => $refOrder['rrn'],
                    'int_ref'     => $refOrder['int_ref'],
                ]);
                $success = ($result['ACTION'] ?? '9') === '0';
                $logger->info('eGW reversal result', [
                    'order_id' => $refOrderId,
                    'rc'       => $result['RC'] ?? '?',
                    'action'   => $result['ACTION'] ?? '?',
                    'success'  => $success,
                ]);
            }

            if ($success) {
                $db->execute("UPDATE vb_orders SET status='refunded', updated_at=NOW() WHERE order_id=?", [$refOrderId]);
                $refundMsg = 'Refund successful for order: ' . $refOrderId;
                $logger->info('Order marked refunded', ['order_id' => $refOrderId]);
            }
            elseif (empty($refundMsg)) {
                $refundMsg = 'Refund failed for order: ' . $refOrderId;
                $logger->error('Refund failed', ['order_id' => $refOrderId]);
            }
        }
        catch (\Exception $e) {
            $refundMsg = 'Refund error: ' . $e->getMessage();
            $logger->error('Refund exception', ['order_id' => $refOrderId, 'error' => $e->getMessage()]);
        }
    }
}

?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>VictoriaBank Gateway — Admin</title>
<style>
  body{font-family:Arial,sans-serif;background:#f5f5f5;margin:0}
  .navbar{background:#c8102e;color:#fff;padding:0 24px;display:flex;align-items:center;height:52px}
  .navbar h1{margin:0;font-size:18px;font-weight:bold}
  .navbar a{color:#fff;text-decoration:none;margin-left:24px;font-size:14px}
  .container{max-width:1100px;margin:24px auto;padding:0 16px}
  .stats{display:flex;gap:16px;flex-wrap:wrap;margin-bottom:24px}
  .stat-card{background:#fff;border-radius:8px;padding:20px 28px;flex:1;min-width:160px;box-shadow:0 1px 4px rgba(0,0,0,.08)}
  .stat-card h3{margin:0 0 8px;color:#888;font-size:13px;text-transform:uppercase}
  .stat-card p{margin:0;font-size:28px;font-weight:bold;color:#333}
  .card{background:#fff;border-radius:8px;padding:20px;box-shadow:0 1px 4px rgba(0,0,0,.08);margin-bottom:20px}
  table{width:100%;border-collapse:collapse;font-size:13px}
  th{text-align:left;padding:10px 12px;border-bottom:2px solid #eee;color:#555;font-weight:600}
  td{padding:9px 12px;border-bottom:1px solid #f0f0f0}
  tr:hover td{background:#fafafa}
  .badge{display:inline-block;padding:3px 10px;border-radius:12px;font-size:11px;font-weight:600}
  .badge-paid{background:#d4edda;color:#155724}
  .badge-pending{background:#fff3cd;color:#856404}
  .badge-failed{background:#f8d7da;color:#721c24}
  .badge-cancelled{background:#e2e3e5;color:#383d41}
  .badge-refunded{background:#d1ecf1;color:#0c5460}
  .btn{display:inline-block;padding:5px 12px;border-radius:4px;text-decoration:none;font-size:12px;font-weight:600}
  .btn-danger{background:#c8102e;color:#fff}
  .btn-danger:hover{background:#a30e26}
  .alert{padding:12px 16px;border-radius:6px;margin-bottom:16px;font-size:14px}
  .alert-success{background:#d4edda;color:#155724;border:1px solid #c3e6cb}
  .alert-warning{background:#fff3cd;color:#856404;border:1px solid #ffeeba}
</style>
</head>
<body>
<div class="navbar">
  <h1>VictoriaBank Gateway</h1>
  <a href="<?= VB_GATEWAY_URL ?>/admin">Dashboard</a>
  <a href="<?= VB_GATEWAY_URL ?>/admin?action=settings">Settings</a>
  <a href="<?= VB_GATEWAY_URL ?>/admin?action=logout">Logout</a>
</div>

<div class="container">
  <?php if (!empty($refundMsg)): ?>
    <div class="alert <?= str_contains($refundMsg, 'success') ? 'alert-success' : 'alert-warning' ?>">
      <?= htmlspecialchars($refundMsg, ENT_QUOTES) ?>
    </div>
  <?php endif; ?>

  <?php if ($action === 'settings'): ?>
    <?php require __DIR__ . '/settings.php'; ?>
  <?php else: ?>
    <!-- Stats -->
    <div class="stats">
      <div class="stat-card"><h3>Total Orders</h3><p><?= (int)$stats['total'] ?></p></div>
      <div class="stat-card"><h3>Paid</h3><p style="color:#155724"><?= (int)$stats['paid'] ?></p></div>
      <div class="stat-card"><h3>Pending</h3><p style="color:#856404"><?= (int)$stats['pending'] ?></p></div>
      <div class="stat-card"><h3>Failed</h3><p style="color:#721c24"><?= (int)$stats['failed'] ?></p></div>
      <div class="stat-card"><h3>Revenue (paid)</h3><p><?= number_format((float)$stats['total_paid'], 2) ?></p></div>
    </div>

    <!-- Orders table -->
    <div class="card">
      <h3 style="margin-top:0">Orders
        <small style="color:#888;font-weight:normal"> &mdash;
          <?php foreach (['', 'paid', 'pending', 'failed', 'cancelled', 'refunded'] as $s): ?>
            <a href="?status=<?= $s ?>" style="color:#c8102e;text-decoration:none;font-size:13px;margin:0 4px">
              <?= $s ?: 'All' ?>
            </a>
          <?php endforeach; ?>
        </small>
      </h3>
      <table>
        <tr>
          <th>Order ID</th><th>Method</th><th>Amount</th><th>Status</th><th>RRN</th><th>Created</th><th>Action</th>
        </tr>
        <?php foreach ($orders as $o): ?>
          <tr>
            <td><?= htmlspecialchars($o['order_id'], ENT_QUOTES) ?></td>
            <td><?= htmlspecialchars(str_replace('_', ' ', ucfirst($o['method'])), ENT_QUOTES) ?></td>
            <td><strong><?= number_format((float)$o['amount'], 2) ?></strong> <?= htmlspecialchars($o['currency'], ENT_QUOTES) ?></td>
            <td>
              <span class="badge badge-<?= htmlspecialchars($o['status'], ENT_QUOTES) ?>">
                <?= htmlspecialchars(ucfirst($o['status']), ENT_QUOTES) ?>
              </span>
            </td>
            <td><?= htmlspecialchars($o['rrn'] ?? '', ENT_QUOTES) ?></td>
            <td><?= htmlspecialchars($o['created_at'], ENT_QUOTES) ?></td>
            <td>
              <?php if ($o['status'] === 'paid'): ?>
                <a href="?action=refund&order_id=<?= urlencode($o['order_id']) ?>"
                   class="btn btn-danger"
                   onclick="return confirm('Refund order <?= htmlspecialchars($o['order_id'], ENT_QUOTES) ?>?')">
                  Refund
                </a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (empty($orders)): ?>
          <tr><td colspan="7" style="text-align:center;color:#888;padding:24px">No orders found.</td></tr>
        <?php endif; ?>
      </table>
    </div>
  <?php endif; ?>
</div>
</body>
</html>
