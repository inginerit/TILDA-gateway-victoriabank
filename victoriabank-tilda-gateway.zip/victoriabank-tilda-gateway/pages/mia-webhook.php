<?php

/**
 * MIA JWT webhook handler.
 * ALWAYS returns HTTP 204. Errors are logged silently.
 */

$rawBody = file_get_contents('php://input');

try {
    processWebhook($rawBody);
}
catch (\Throwable $e) {
    vb_logger()->error('MIA webhook exception: ' . $e->getMessage());
}

// ALWAYS 204
http_response_code(204);
exit;

function processWebhook(string $rawBody): void
{
    if (!$rawBody) {
        vb_logger()->warning('MIA webhook: empty body');
        return;
    }

    $verifier = vb_jwt();
    $payload  = $verifier->verifyAndDecode($rawBody);

    if (!$payload) {
        vb_logger()->error('MIA webhook: JWT verification FAILED');
        return;
    }

    $signalCode = $payload['signalCode'] ?? '';
    $qrUuid     = $payload['qrExtensionUUID'] ?? '';

    vb_logger()->info('MIA webhook', ['signal' => $signalCode, 'uuid' => $qrUuid]);

    if (!in_array($signalCode, ['Payment', 'Expiration', 'Inactivation'])) {
        return;
    }

    if (!preg_match('/^[a-f0-9\-]{36}$/i', $qrUuid)) {
        vb_logger()->error('MIA webhook: invalid UUID', ['uuid' => $qrUuid]);
        return;
    }

    $db    = vb_db();
    $order = $db->fetchOne('SELECT * FROM vb_orders WHERE mia_qr_uuid = ? LIMIT 1', [$qrUuid]);

    if (!$order) {
        vb_logger()->warning('MIA webhook: no order for UUID', ['uuid' => $qrUuid]);
        return;
    }

    $orderId = $order['order_id'];

    switch ($signalCode) {
        case 'Payment':
            $payment   = $payload['payment'] ?? [];
            $reference = $payment['reference'] ?? '';
            $amount    = (float) ($payment['amount']['sum'] ?? 0);
            $currency  = $payment['amount']['currency'] ?? 'MDL';

            if (!$reference || $amount <= 0) {
                vb_logger()->error('MIA webhook Payment: missing reference or amount', ['order_id' => $orderId]);
                return;
            }

            $db->execute(
                'UPDATE vb_orders SET status="paid", mia_reference=?, updated_at=NOW() WHERE order_id=?',
                [$reference, $orderId]
            );

            vb_logger()->info('MIA payment confirmed', [
                'order_id'  => $orderId,
                'reference' => $reference,
                'amount'    => $amount,
            ]);

            // Notify merchant
            if (!empty($order['notify_url'])) {
                $payload_json = json_encode([
                    'order_id'  => $orderId,
                    'status'    => 'paid',
                    'amount'    => $amount,
                    'currency'  => $currency,
                    'reference' => $reference,
                    'timestamp' => gmdate('c'),
                ]);
                $ch = curl_init($order['notify_url']);
                curl_setopt_array($ch, [
                    CURLOPT_POST           => true,
                    CURLOPT_POSTFIELDS     => $payload_json,
                    CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_TIMEOUT        => 10,
                ]);
                curl_exec($ch);
                curl_close($ch);
            }
            break;

        case 'Expiration':
            $db->execute(
                'UPDATE vb_orders SET status="cancelled", updated_at=NOW() WHERE order_id=? AND status="pending"',
                [$orderId]
            );
            break;

        case 'Inactivation':
            vb_logger()->info('MIA inactivation', ['order_id' => $orderId]);
            break;
    }
}
