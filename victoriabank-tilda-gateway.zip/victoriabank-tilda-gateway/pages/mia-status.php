<?php

/**
 * MIA status polling endpoint — returns JSON.
 */

header('Content-Type: application/json; charset=utf-8');

$uuid = htmlspecialchars($_GET['uuid'] ?? '', ENT_QUOTES);

if (!$uuid || !preg_match('/^[a-f0-9\-]{36}$/i', $uuid)) {
    echo json_encode(['error' => 'Invalid UUID']);
    exit;
}

$db    = vb_db();
$order = $db->fetchOne('SELECT * FROM vb_orders WHERE mia_qr_uuid = ? LIMIT 1', [$uuid]);

if (!$order) {
    echo json_encode(['status' => 'NotFound']);
    exit;
}

// If already in final state, return immediately
$finalStatuses = ['paid', 'cancelled', 'failed', 'refunded'];
if (in_array($order['status'], $finalStatuses)) {
    $miaStatus = match ($order['status']) {
        'paid'      => 'Paid',
        'cancelled' => 'Cancelled',
        default     => 'Inactive',
    };
    echo json_encode(['status' => $miaStatus]);
    exit;
}

// Status polling requires qrHeaderUUID (not extension UUID)
$headerUuid = $order['mia_qr_header_uuid'] ?? '';
if (!$headerUuid) {
    // No header UUID stored — cannot poll (old record or QR not yet created)
    echo json_encode(['status' => 'Active']);
    exit;
}

// Poll MIA API: GET /api/v1/qr/{qrHeaderUUID}/status
try {
    $mia       = vb_mia();
    $apiStatus = $mia->checkStatus($headerUuid);
    $status    = $apiStatus['status'] ?? 'Unknown';
    $rawData   = $apiStatus['raw'] ?? [];

    vb_logger()->debug('MIA status polled', [
        'extension_uuid' => $uuid,
        'header_uuid'    => $headerUuid,
        'status'         => $status,
    ]);

    // On Paid: extract payment reference from extensions[]
    if ($status === 'Paid') {
        $reference = '';
        $extensions = $rawData['extensions'] ?? [];
        foreach ($extensions as $ext) {
            if (($ext['uuid'] ?? '') === $uuid) {
                $payment   = $ext['payments'][0] ?? [];
                $reference = (string) ($payment['reference'] ?? '');
                break;
            }
        }

        $db->execute(
            'UPDATE vb_orders SET status="paid", mia_reference=?, updated_at=NOW() WHERE order_id=? AND status="pending"',
            [$reference, $order['order_id']]
        );

        vb_logger()->info('MIA payment confirmed via polling', [
            'order_id'  => $order['order_id'],
            'reference' => $reference,
        ]);
    } elseif (in_array($status, ['Expired', 'Cancelled', 'Inactive'])) {
        $dbStatus = ($status === 'Expired' || $status === 'Cancelled') ? 'cancelled' : 'failed';
        $db->execute(
            'UPDATE vb_orders SET status=?, updated_at=NOW() WHERE order_id=? AND status="pending"',
            [$dbStatus, $order['order_id']]
        );
    }

    echo json_encode([
        'status'     => $status,
        'return_url' => $order['return_url'] ?? '',
        'cancel_url' => $order['cancel_url'] ?? '',
    ]);
}
catch (\Exception $e) {
    vb_logger()->error('MIA status check failed: ' . $e->getMessage(), ['uuid' => $uuid]);
    // Return Active to keep JS polling — don't stop on transient errors
    echo json_encode(['status' => 'Active']);
}

exit;
