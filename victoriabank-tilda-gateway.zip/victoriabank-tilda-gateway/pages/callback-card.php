<?php

/**
 * Bank callback handler for e-Gateway (Visa/Master, StarCard Rate/Points).
 *
 * Two-phase payment flow:
 *   TRTYPE=0  → Authorization confirmed → save RRN/INT_REF → send TRTYPE=21 → return 200
 *   TRTYPE=21 → Completion confirmed    → mark order PAID (idempotent)
 *   TRTYPE=24 → Reversal confirmed      → mark refunded
 *
 * P_SIGN invalid → always return HTTP 200 (do not expose info to attacker).
 */

require_once dirname(__DIR__) . '/config.php';

$allowed = [
    'ORDER', 'TERMINAL', 'TRTYPE', 'AMOUNT', 'CURRENCY',
    'ACTION', 'RC', 'TEXT', 'APPROVAL', 'RRN', 'INT_REF',
    'TIMESTAMP', 'NONCE', 'P_SIGN', 'BIN', 'CARD', 'AUTH', 'ECI', 'Function',
];

// Collect POST params
$params = [];
foreach ($allowed as $field) {
    if (isset($_POST[$field])) {
        $params[$field] = $_POST[$field];
    }
}

// Fallback: parse raw body
if (empty($params)) {
    $rawBody = file_get_contents('php://input');
    if ($rawBody) {
        $parsed = vb_egw()->getVerifier()->parseResponse($rawBody);
        foreach ($allowed as $field) {
            if (isset($parsed[$field])) {
                $params[$field] = $parsed[$field];
            }
        }
    }
}

$trtype   = (string)($params['TRTYPE'] ?? '');
$bankOrder = $params['ORDER'] ?? '';  // bank ORDER (numeric, zero-padded e.g. "000001")
$dbId      = (int) ltrim($bankOrder, '0');  // strip leading zeros → DB auto-increment id

vb_logger()->info('Callback received', [
    'ORDER'  => $bankOrder ?: '?',
    'TRTYPE' => $trtype,
    'ACTION' => $params['ACTION'] ?? '?',
    'RC'     => $params['RC'] ?? '?',
    'TEXT'   => $params['TEXT'] ?? '',
    'RRN'    => $params['RRN'] ?? '',
]);
// Debug: log all callback params (P_SIGN truncated)
$debugParams = $params;
if (isset($debugParams['P_SIGN'])) {
    $debugParams['P_SIGN'] = substr($debugParams['P_SIGN'], 0, 32) . '...(len=' . strlen($params['P_SIGN']) . ')';
}
vb_logger()->debug('Callback full params: ' . json_encode($debugParams));

if (!$dbId) {
    vb_logger()->error('Callback: missing or zero ORDER param');
    http_response_code(400);
    exit('Bad request');
}

$egw      = vb_egw();
$verifier = $egw->getVerifier();
$db       = vb_db();

// ORDER = DB auto-increment id (numeric); look up order by id, not by external order_id
$order = $db->fetchOne('SELECT * FROM vb_orders WHERE id = ? LIMIT 1', [$dbId]);
if (!$order) {
    vb_logger()->error('Callback: order not found', ['bank_order' => $bankOrder, 'db_id' => $dbId]);
    http_response_code(200);
    exit('OK');
}

// Restore external order_id for all subsequent SQL/logging (all UPDATEs use WHERE order_id=?)
$orderId = $order['order_id'];

// Verify P_SIGN — always return 200 on failure (do not leak info to attacker)
$psignOk = $verifier->verify($params);
vb_logger()->debug('P_SIGN verify result: ' . ($psignOk ? 'OK' : 'FAILED'), ['order_id' => $orderId]);
if (!$psignOk) {
    vb_logger()->error('Callback: P_SIGN FAILED', ['order_id' => $orderId, 'trtype' => $trtype]);
    http_response_code(200);
    exit('OK');
}

// Route by TRTYPE
switch ($trtype) {

    // ── TRTYPE=0: Authorization confirmed ────────────────────────────────────
    case '0':
        $rc     = (string)($params['RC']      ?? '');
        $action = (string)($params['ACTION']  ?? '');
        $rrn    = (string)($params['RRN']     ?? '');
        $intRef = (string)($params['INT_REF'] ?? '');
        $amount = (float)($params['AMOUNT']   ?? $order['amount'] ?? 0);
        $method = $order['method'] ?? 'visa_master';
        $curr   = match ($method) {
            'starcard_points' => '06S',
            'starcard_rate'   => 'MDL',
            default           => $params['CURRENCY'] ?? ($order['currency'] ?? 'MDL'),
        };

        // Already in terminal state?
        if (in_array($order['status'] ?? '', ['paid', 'cancelled', 'refunded'], true)) {
            vb_logger()->info('TRTYPE=0: already in terminal state', ['order_id' => $orderId, 'status' => $order['status']]);
            http_response_code(200);
            exit('OK');
        }

        // Customer cancelled (RC=-25)
        if ($rc === '-25') {
            $db->execute(
                'UPDATE vb_orders SET status="cancelled", raw_callback=?, updated_at=NOW() WHERE order_id=?',
                [json_encode($params), $orderId]
            );
            vb_logger()->info('TRTYPE=0: cancelled by customer', ['order_id' => $orderId]);
            http_response_code(200);
            exit('OK');
        }

        // Payment declined
        if ($rc !== '00' || $action !== '0') {
            $db->execute(
                'UPDATE vb_orders SET status="failed", raw_callback=?, updated_at=NOW() WHERE order_id=?',
                [json_encode($params), $orderId]
            );
            vb_logger()->warning('TRTYPE=0: declined', ['order_id' => $orderId, 'rc' => $rc]);
            http_response_code(200);
            exit('OK');
        }

        // Save authorization state
        $db->execute(
            'UPDATE vb_orders SET status="authorized", rrn=?, int_ref=?, raw_callback=?, updated_at=NOW() WHERE order_id=?',
            [$rrn, $intRef, json_encode($params), $orderId]
        );

        vb_logger()->info('TRTYPE=0: authorized — sending TRTYPE=21', [
            'order_id' => $orderId, 'rrn' => $rrn,
        ]);

        // Send TRTYPE=21 completion
        // IMPORTANT: order_id must be the numeric DB id (bank ORDER), not the external order_id string
        $isStarCard   = in_array($method, ['starcard_rate', 'starcard_points'], true);
        $terminalId21 = ($isStarCard && VB_SC_TERMINAL) ? VB_SC_TERMINAL : VB_EGW_TERMINAL;
        $gen = $egw->getGenerator();
        try {
            $completionParams = $gen->buildCompletionParams([
                'order_id'    => $dbId,   // numeric bank ORDER (e.g. 4 → "000004")
                'amount'      => $amount,
                'currency'    => $curr,
                'terminal_id' => $terminalId21,
                'rrn'         => $rrn,
                'int_ref'     => $intRef,
            ]);
            $result = $egw->sendRequest($completionParams);
            $rc21   = (string)($result['RC'] ?? '');

            vb_logger()->info('TRTYPE=21 sent', ['order_id' => $orderId, 'rc' => $rc21]);

            if ($rc21 === '00') {
                $db->execute(
                    'UPDATE vb_orders SET status="processing", sent_21_at=NOW() WHERE order_id=?',
                    [$orderId]
                );
            }
        }
        catch (\Exception $e) {
            vb_logger()->error('TRTYPE=21 exception: ' . $e->getMessage(), ['order_id' => $orderId]);
        }

        http_response_code(200);
        exit('OK');

    // ── TRTYPE=21: Completion confirmed ──────────────────────────────────────
    case '21':
        $rc     = (string)($params['RC']     ?? '');
        $action = (string)($params['ACTION'] ?? '');
        $rrn    = (string)($params['RRN']    ?? '');

        // Idempotency: already paid?
        if (($order['completion_done'] ?? 0)) {
            vb_logger()->info('TRTYPE=21: already marked paid', ['order_id' => $orderId]);
            http_response_code(200);
            exit('OK');
        }

        if ($rc === '00' && $action === '0') {
            $db->execute(
                'UPDATE vb_orders SET status="paid", rrn=?, completion_done=1, raw_callback=?, updated_at=NOW() WHERE order_id=?',
                [$rrn, json_encode($params), $orderId]
            );

            vb_logger()->info('TRTYPE=21: payment completed', ['order_id' => $orderId, 'rrn' => $rrn]);

            // Notify merchant via webhook if configured
            if (!empty($order['notify_url'])) {
                $payload = json_encode([
                    'order_id'  => $orderId,
                    'status'    => 'paid',
                    'amount'    => $order['amount'],
                    'currency'  => $order['currency'] ?? 'MDL',
                    'rrn'       => $rrn,
                    'timestamp' => gmdate('c'),
                ]);
                $ch = curl_init($order['notify_url']);
                curl_setopt_array($ch, [
                    CURLOPT_POST           => true,
                    CURLOPT_POSTFIELDS     => $payload,
                    CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_TIMEOUT        => 10,
                ]);
                curl_exec($ch);
                curl_close($ch);
            }
        }
        else {
            vb_logger()->warning('TRTYPE=21: completion failed', ['order_id' => $orderId, 'rc' => $rc]);
        }

        http_response_code(200);
        exit('OK');

    // ── TRTYPE=24: Reversal/refund confirmed ──────────────────────────────────
    case '24':
        $rc     = (string)($params['RC']     ?? '');
        $action = (string)($params['ACTION'] ?? '');
        $rrn    = (string)($params['RRN']    ?? '');

        if ($rc === '00' && $action === '0') {
            $db->execute(
                'UPDATE vb_orders SET status="refunded", raw_callback=?, updated_at=NOW() WHERE order_id=?',
                [json_encode($params), $orderId]
            );
            vb_logger()->info('TRTYPE=24: refund confirmed', ['order_id' => $orderId, 'rrn' => $rrn]);
        }
        else {
            vb_logger()->warning('TRTYPE=24: reversal failed', ['order_id' => $orderId, 'rc' => $rc]);
        }

        http_response_code(200);
        exit('OK');

    default:
        vb_logger()->info('Callback: unknown TRTYPE', ['trtype' => $trtype, 'order_id' => $orderId]);
        http_response_code(200);
        exit('OK');
}
