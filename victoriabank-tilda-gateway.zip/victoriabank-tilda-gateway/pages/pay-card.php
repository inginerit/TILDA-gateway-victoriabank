<?php

/**
 * Card payment page — builds TRTYPE=0 and redirects to bank.
 *
 * Expected GET params:
 *   method       = visa_master | starcard_rate | starcard_points
 *   order_id     = merchant order ID (string)
 *   amount       = decimal (e.g. 150.00)
 *   currency     = MDL | EUR | USD  (Visa/Master accepts all three;
 *                  StarCard Rate always uses MDL;
 *                  StarCard Points always uses 06S — both overridden automatically)
 *   description  = text
 *   return_url   = success redirect
 *   cancel_url   = cancel redirect
 *   notify_url   = webhook notification URL (optional)
 */

$method   = htmlspecialchars($_GET['method'] ?? 'visa_master', ENT_QUOTES);
$orderId  = htmlspecialchars($_GET['order_id'] ?? '', ENT_QUOTES);
$amount   = filter_var($_GET['amount'] ?? 0, FILTER_VALIDATE_FLOAT);
$desc     = htmlspecialchars(trim($_GET['description'] ?? 'Order ' . $orderId), ENT_QUOTES);
$returnUrl = filter_var($_GET['return_url'] ?? '', FILTER_VALIDATE_URL) ?: '';
$cancelUrl = filter_var($_GET['cancel_url'] ?? '', FILTER_VALIDATE_URL) ?: '';
$notifyUrl = filter_var($_GET['notify_url'] ?? '', FILTER_VALIDATE_URL) ?: '';

// Read requested currency — validated against allowed values
$requestedCurrency = strtoupper(htmlspecialchars($_GET['currency'] ?? 'MDL', ENT_QUOTES));

// Validate
if (!$orderId || !$amount || $amount <= 0) {
    http_response_code(400);
    die('Invalid payment parameters');
}

$allowedMethods = ['visa_master', 'starcard_rate', 'starcard_points'];
if (!in_array($method, $allowedMethods, true)) {
    http_response_code(400);
    die('Invalid payment method');
}

// Check method enabled
$enabledMap = [
    'visa_master'     => VB_ENABLE_VISA,
    'starcard_rate'   => VB_ENABLE_RATE,
    'starcard_points' => VB_ENABLE_POINTS,
];
if (!$enabledMap[$method]) {
    http_response_code(400);
    die('Payment method not available');
}

// Determine currency — Visa/Master: MDL|EUR|USD from request; others fixed
$allowedCurrencies = ['MDL', 'EUR', 'USD'];
$currency = match ($method) {
    'starcard_points' => '06S',
    'starcard_rate'   => 'MDL',
    default           => in_array($requestedCurrency, $allowedCurrencies, true) ? $requestedCurrency : 'MDL',
};

// Save order to DB — get or create by external order_id
// The auto-increment `id` is used as the bank ORDER (must be numeric per bank spec)
$db = vb_db();
$existing = $db->fetchOne('SELECT id FROM vb_orders WHERE order_id = ? LIMIT 1', [$orderId]);
if ($existing) {
    $bankOrderNum = (int) $existing['id'];
    $db->execute('UPDATE vb_orders SET status="pending", updated_at=NOW() WHERE order_id=?', [$orderId]);
} else {
    $bankOrderNum = (int) $db->insert(
        'INSERT INTO vb_orders (order_id, method, amount, currency, status, return_url, cancel_url, notify_url, description)
         VALUES (?, ?, ?, ?, "pending", ?, ?, ?, ?)',
        [$orderId, $method, $amount, $currency, $returnUrl, $cancelUrl, $notifyUrl, $desc]
    );
}

// Build callback URL
$callbackUrl = VB_GATEWAY_URL . '/callback';

// Resolve terminal/merchant — StarCard uses separate credentials if configured
$isStarCard = in_array($method, ['starcard_rate', 'starcard_points'], true);
$terminalId = ($isStarCard && VB_SC_TERMINAL) ? VB_SC_TERMINAL : VB_EGW_TERMINAL;
$merchantId = ($isStarCard && VB_SC_MERCHANT) ? VB_SC_MERCHANT : VB_EGW_MERCHANT;

// Build auth params — ORDER must be numeric (bank spec), use DB auto-increment id
$egw    = vb_egw();
$gen    = $egw->getGenerator();

$params = $gen->buildAuthParams([
    'order_id'         => $bankOrderNum,
    'amount'           => $amount,
    'currency'         => $currency,
    'terminal_id'      => $terminalId,
    'merchant_id'      => $merchantId,
    'merchant_name'    => VB_EGW_MERCH_NAME,
    'merchant_url'     => VB_EGW_MERCH_URL,
    'merchant_address' => VB_CONFIG['egw']['merchant_address'] ?? '',
    'merchant_gmt'     => VB_EGW_GMT,
    'country'          => 'md',
    'language'         => VB_EGW_LANG,
    'backref'          => $callbackUrl,
    'description'      => $desc,
], $method === 'starcard_points');

vb_logger()->info('Card payment initiated', [
    'order_id'       => $orderId,
    'bank_order_num' => $bankOrderNum,
    'method'         => $method,
    'amount'         => $amount,
    'currency'       => $currency,
    'callback_url'   => $callbackUrl,
    'endpoint'       => $egw->getEndpoint(),
]);

// Debug: log all params sent to bank (P_SIGN truncated)
$paramsLog = $params;
$paramsLog['P_SIGN'] = substr($paramsLog['P_SIGN'] ?? '', 0, 32) . '...';
vb_logger()->debug('Bank request params: ' . json_encode($paramsLog));

// Render auto-submit form
$endpoint = $egw->getEndpoint();
$fields   = '';
foreach ($params as $name => $value) {
    $fields .= '<input type="hidden" name="' . htmlspecialchars($name, ENT_QUOTES) . '" value="' . htmlspecialchars((string) $value, ENT_QUOTES) . '">' . "\n";
}

?><!DOCTYPE html>
<html lang="ro">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Redirecting to VictoriaBank...</title>
<style>
body { font-family: Arial, sans-serif; text-align: center; padding: 80px 20px; background: #f4f4f4; }
.loader { border: 5px solid #eee; border-top: 5px solid #c8102e; border-radius: 50%; width: 50px; height: 50px; animation: spin 1s linear infinite; margin: 24px auto; }
@keyframes spin { 0%{transform:rotate(0deg)} 100%{transform:rotate(360deg)} }
p { color: #666; font-size: 15px; }
</style>
</head>
<body>
<div class="loader"></div>
<p>Vă redirecționăm la pagina de plată securizată VictoriaBank...</p>
<form id="vbf" method="POST" action="<?= htmlspecialchars($endpoint, ENT_QUOTES) ?>">
<?= $fields ?>
</form>
<script>document.addEventListener('DOMContentLoaded',function(){document.getElementById('vbf').submit();});</script>
</body>
</html>
