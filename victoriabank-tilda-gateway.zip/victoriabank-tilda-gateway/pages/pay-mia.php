<?php

/**
 * MIA Instant Payment page — creates QR, shows payment UI.
 *
 * Expected GET params:
 *   order_id     = merchant order ID
 *   amount       = decimal
 *   currency     = MDL
 *   description  = text
 *   return_url, cancel_url, notify_url
 */

if (!VB_ENABLE_MIA) {
    http_response_code(400);
    die('MIA payment is not enabled');
}

$orderId   = htmlspecialchars($_GET['order_id'] ?? '', ENT_QUOTES);
$amount    = filter_var($_GET['amount'] ?? 0, FILTER_VALIDATE_FLOAT);
$currency  = htmlspecialchars($_GET['currency'] ?? 'MDL', ENT_QUOTES);
$desc      = htmlspecialchars(trim($_GET['description'] ?? 'Order ' . $orderId), ENT_QUOTES);
$returnUrl = filter_var($_GET['return_url'] ?? '', FILTER_VALIDATE_URL) ?: VB_GATEWAY_URL . '/success';
$cancelUrl = filter_var($_GET['cancel_url'] ?? '', FILTER_VALIDATE_URL) ?: VB_GATEWAY_URL . '/cancel';
$notifyUrl = filter_var($_GET['notify_url'] ?? '', FILTER_VALIDATE_URL) ?: '';

if (!$orderId || !$amount || $amount <= 0) {
    http_response_code(400);
    die('Invalid parameters');
}

$db = vb_db();

// Save order
$db->execute(
    'INSERT INTO vb_orders (order_id, method, amount, currency, status, return_url, cancel_url, notify_url, description)
     VALUES (?, "mia", ?, ?, "pending", ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE status="pending", updated_at=NOW()',
    [$orderId, $amount, $currency, $returnUrl, $cancelUrl, $notifyUrl, $desc]
);

// Create MIA QR
$mia = vb_mia();

try {
    $qr = $mia->createQr([
        'amount'        => $amount,
        'currency'      => $currency,
        'iban'          => VB_MIA_IBAN,
        'merchant_name' => VB_EGW_MERCH_NAME,
        'description'   => $desc,
        'order_ref'     => 'ORDER-' . $orderId,
        'ttl_minutes'   => 5,
        'return_url'    => $returnUrl,
    ]);
}
catch (\Exception $e) {
    vb_logger()->error('MIA QR creation failed: ' . $e->getMessage(), ['order_id' => $orderId]);
    http_response_code(500);
    die('QR creation failed. Please try again.');
}

// Save both UUIDs: extension UUID for display/JS, header UUID for status polling
$db->execute(
    'UPDATE vb_orders SET mia_qr_uuid=?, mia_qr_header_uuid=?, updated_at=NOW() WHERE order_id=?',
    [$qr['qrExtensionUUID'], $qr['qrHeaderUUID'], $orderId]
);

vb_logger()->info('MIA QR created', [
    'order_id'        => $orderId,
    'extension_uuid'  => $qr['qrExtensionUUID'],
    'header_uuid'     => $qr['qrHeaderUUID'],
    'amount'          => $amount,
]);

$qrImage  = $qr['qrAsImage'] ?? '';
$qrText   = $qr['qrAsText'] ?? '';
$uuid     = $qr['qrExtensionUUID'];
$statusUrl = VB_GATEWAY_URL . '/mia/status';

?><!DOCTYPE html>
<html lang="ro">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Plată MIA — VictoriaBank</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: Arial, sans-serif; text-align: center; background: #f5f5f5; margin: 0; padding: 30px 16px; }
  .container { max-width: 480px; margin: 0 auto; background: #fff; border-radius: 12px; padding: 32px 24px; box-shadow: 0 2px 16px rgba(0,0,0,0.1); }
  h2 { color: #c8102e; margin-bottom: 8px; }
  .amount { font-size: 28px; font-weight: bold; color: #333; margin: 12px 0; }
  .qr-img { border: 2px solid #eee; padding: 8px; border-radius: 8px; margin: 16px auto; display: block; }
  #vb-status-msg { color: #888; font-size: 14px; margin-top: 12px; }
  .btn-open { display: inline-block; background: #c8102e; color: #fff; padding: 16px 36px; border-radius: 8px; text-decoration: none; font-size: 18px; margin: 16px 0; }
  .btn-open:hover { background: #a30e26; }
</style>
</head>
<body>
<div class="container">
  <h2>Plată MIA</h2>
  <p class="amount"><?= htmlspecialchars(number_format($amount, 2), ENT_QUOTES) ?> <?= htmlspecialchars($currency, ENT_QUOTES) ?></p>

  <div id="vb-mia-wrapper"
       data-uuid="<?= htmlspecialchars($uuid, ENT_QUOTES) ?>"
       data-return-url="<?= htmlspecialchars($returnUrl, ENT_QUOTES) ?>"
       data-cancel-url="<?= htmlspecialchars($cancelUrl, ENT_QUOTES) ?>"
       data-status-url="<?= htmlspecialchars($statusUrl, ENT_QUOTES) ?>">

    <div id="vb-desktop">
      <p>Deschideți aplicația bancară și scanați codul QR pentru a efectua plata.</p>
      <?php if ($qrImage): ?>
        <img src="data:image/png;base64,<?= htmlspecialchars($qrImage, ENT_QUOTES) ?>"
             alt="VictoriaBank MIA QR" width="280" height="280" class="qr-img">
      <?php endif; ?>
      <p id="vb-status-msg">Se așteaptă plata...</p>
    </div>

    <div id="vb-mobile" style="display:none;">
      <p>Apăsați butonul pentru a deschide aplicația bancară.</p>
      <a id="vb-deeplink-btn" href="#" class="btn-open">Deschide Aplicația Bancară</a>
      <br>
      <small style="color:#999;">Dacă aplicația nu se deschide, scanați codul QR pe alt dispozitiv.</small>
      <?php if ($qrImage): ?>
        <br><br>
        <img src="data:image/png;base64,<?= htmlspecialchars($qrImage, ENT_QUOTES) ?>"
             alt="QR" width="200" height="200" class="qr-img">
      <?php endif; ?>
      <p id="vb-status-msg-mobile">Se așteaptă plata...</p>
    </div>

  </div>
</div>

<script>
var vbQrText = <?= json_encode($qrText) ?>;
</script>
<script src="<?= htmlspecialchars(VB_GATEWAY_URL, ENT_QUOTES) ?>/assets/js/mia-payment.js"></script>
</body>
</html>
