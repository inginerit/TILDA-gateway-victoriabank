<?php

/**
 * VictoriaBank Tilda Gateway — configuration loader.
 * Reads config.json and sets global constants / functions.
 */

define('VB_ROOT', __DIR__);

$configFile = VB_ROOT . '/config.json';
if (!file_exists($configFile)) {
    http_response_code(500);
    die('Gateway not configured. Please copy config.json.template to config.json and fill in your values.');
}

$config = json_decode(file_get_contents($configFile), true);
if (!$config) {
    http_response_code(500);
    die('Invalid config.json');
}

define('VB_CONFIG', $config);
define('VB_TEST_MODE',       (bool) ($config['test_mode'] ?? true));
define('VB_ADMIN_PASSWORD',  $config['admin_password'] ?? '');
define('VB_GATEWAY_URL',     rtrim($config['gateway_url'] ?? '', '/'));
define('VB_LOG_DIR',         $config['log_dir'] ?? VB_ROOT . '/logs');

// e-Gateway config
define('VB_EGW_TERMINAL',   $config['egw']['terminal_id'] ?? '');
define('VB_EGW_MERCHANT',   $config['egw']['merchant_id'] ?? '');
// StarCard uses separate terminal/merchant if configured, otherwise falls back to main
define('VB_SC_TERMINAL',    $config['egw']['starcard_terminal_id'] ?? '');
define('VB_SC_MERCHANT',    $config['egw']['starcard_merchant_id'] ?? '');
define('VB_EGW_MERCH_NAME', $config['egw']['merchant_name'] ?? '');
define('VB_EGW_MERCH_URL',  $config['egw']['merchant_url'] ?? '');
define('VB_EGW_MERCH_ADDR', $config['egw']['merchant_address'] ?? '');
define('VB_EGW_GMT',        $config['egw']['merchant_gmt'] ?? '+02:00');
define('VB_EGW_LANG',       $config['egw']['language'] ?? 'RO');

// Key files
$privKeyPath = $config['egw']['private_key_path'] ?? '';
$pubKeyPath  = $config['egw']['public_key_path'] ?? '';
define('VB_PRIVATE_KEY_PEM', $privKeyPath && file_exists($privKeyPath) ? file_get_contents($privKeyPath) : '');
define('VB_PUBLIC_KEY_PEM',  $pubKeyPath && file_exists($pubKeyPath) ? file_get_contents($pubKeyPath) : '');

// MIA config
define('VB_MIA_USERNAME',   $config['mia']['api_username'] ?? '');
define('VB_MIA_PASSWORD',   $config['mia']['api_password'] ?? '');
define('VB_MIA_IBAN',       $config['mia']['merchant_iban'] ?? '');
define('VB_MIA_CERT_PATH',  $config['mia']['vbca_cert_path'] ?? '');

// Payment methods enabled
define('VB_ENABLE_VISA',   (bool) ($config['payment_methods']['visa_master'] ?? true));
define('VB_ENABLE_RATE',   (bool) ($config['payment_methods']['starcard_rate'] ?? true));
define('VB_ENABLE_POINTS', (bool) ($config['payment_methods']['starcard_points'] ?? true));
define('VB_ENABLE_MIA',    (bool) ($config['payment_methods']['mia'] ?? true));

// Autoload src classes
spl_autoload_register(function (string $class): void {
    $file = VB_ROOT . '/src/' . $class . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

// Require src classes immediately
require_once VB_ROOT . '/src/Database.php';
require_once VB_ROOT . '/src/Logger.php';
require_once VB_ROOT . '/src/PSignGenerator.php';
require_once VB_ROOT . '/src/PSignVerifier.php';
require_once VB_ROOT . '/src/EGatewayClient.php';
require_once VB_ROOT . '/src/MiaApiClient.php';
require_once VB_ROOT . '/src/MiaJwtVerifier.php';

// Initialize shared instances
function vb_db(): VbDatabase {
    static $db = null;
    if ($db === null) {
        $db = VbDatabase::getInstance(VB_CONFIG['db']);
    }
    return $db;
}

function vb_logger(): VbLogger {
    static $log = null;
    if ($log === null) {
        $log = VbLogger::getInstance(VB_LOG_DIR);
    }
    return $log;
}

function vb_egw(): VbEGatewayClient {
    static $egw = null;
    if ($egw === null) {
        $egw = new VbEGatewayClient(VB_PRIVATE_KEY_PEM, VB_PUBLIC_KEY_PEM, VB_TEST_MODE);
    }
    return $egw;
}

function vb_mia(): VbMiaApiClient {
    static $mia = null;
    if ($mia === null) {
        $mia = new VbMiaApiClient(vb_db(), VB_MIA_USERNAME, VB_MIA_PASSWORD, VB_TEST_MODE);
    }
    return $mia;
}

function vb_jwt(): VbMiaJwtVerifier {
    static $jwt = null;
    if ($jwt === null) {
        $jwt = new VbMiaJwtVerifier(VB_MIA_CERT_PATH);
    }
    return $jwt;
}
